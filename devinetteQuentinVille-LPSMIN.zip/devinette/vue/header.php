<header>
	<h1>Jeu du nombre PHP</h1>
</header>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/style.css">