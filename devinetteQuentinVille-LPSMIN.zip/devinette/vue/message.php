<!DOCTYPE HTML>
<html>
<head>
</head>
<body>

   <p> <?php echo $VUE['message'];?></p>

   <p> <a href="<?php echo $VUE['suite'];?>">
	<?php echo $VUE['message'];?></a></p>

</body>
</html>