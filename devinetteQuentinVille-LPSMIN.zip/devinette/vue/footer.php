<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/style.css">

<footer>

    <p>Copyright &copy 2015 - Quentin Ville</p>
</footer>