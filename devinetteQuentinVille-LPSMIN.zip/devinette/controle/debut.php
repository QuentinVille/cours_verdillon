<?php
$_SESSION['essais']= 0;
$_SESSION['ecranChoixNiveau']=0;
$VUE['message'] = 'Bienvenue! nouvelle partie ?';
require("vue/formulaire.php");
?>